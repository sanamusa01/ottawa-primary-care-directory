#!/usr/bin/env python3
"""Build the Ottawa Primary Care Directory WordPress plugin from the source HTML.

The HTML file in the Monica workspace is the authoritative source. This script
performs only mechanical extraction and WordPress-specific wrapping so that the
large JSON payload is not stored in WordPress post content.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "Ottawa-Primary-Care-Directory-CLEANED_16.html"
PLUGIN = ROOT / "ottawa-primary-care-directory"


def write_generated(relative_path: str, content: str) -> None:
    path = PLUGIN / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def extract_source() -> tuple[str, str, str, dict]:
    source = SOURCE.read_text(encoding="utf-8")
    begin = source.index("<!-- ===== BEGIN PASTE BLOCK")
    end = source.index("<!-- ===== END PASTE BLOCK", begin)
    paste = source[begin:end]

    style_match = re.search(r"<style>([\s\S]*?)</style>", paste)
    if not style_match:
        raise RuntimeError("Directory style block was not found")

    data_open = '<script type="application/json" id="ottrx-data">'
    data_start = paste.index(data_open, style_match.end())
    data_end = paste.index("</script>", data_start)
    script_start = paste.index("<script>", data_end) + len("<script>")
    script_end = paste.index("</script>", script_start)

    css = style_match.group(1).strip() + "\n"
    markup = paste[style_match.end():data_start].strip()
    data_text = paste[data_start + len(data_open):data_end]
    javascript = paste[script_start:script_end].strip() + "\n"
    data = json.loads(data_text)
    return css, markup, javascript, data


def wordpress_markup(markup: str) -> str:
    markup = re.sub(
        r'href="file:[^"]*#ottrx-panel"',
        'href="#ottrx-panel"',
        markup,
    )
    markup = markup.replace(
        '<div id="ottrx-root" class="ottrx" lang="en">',
        '<div id="ottrx-root" class="ottrx ottrx--wordpress" '
        'lang="<?php echo esc_attr( $directory_language ); ?>" '
        'data-data-url="<?php echo esc_url( $directory_data_url ); ?>" '
        'data-leaflet-css="<?php echo esc_url( $leaflet_css_url ); ?>" '
        'data-leaflet-js="<?php echo esc_url( $leaflet_js_url ); ?>" '
        'aria-busy="true">',
    )

    loading = (
        '<main class="ottrx__panel" id="ottrx-panel" role="tabpanel" '
        'tabindex="-1" data-panel aria-labelledby="ottrx-tab-referral">'
        '<div class="ottrx__loading" role="status" aria-live="polite">'
        '<span class="ottrx__spinner" aria-hidden="true"></span>'
        '<span>Loading directory…</span></div>'
        '<noscript><div class="ottrx__warn">JavaScript is required to use this '
        'interactive directory.</div></noscript></main>'
    )
    markup, count = re.subn(
        r'<main class="ottrx__panel"[\s\S]*?</main>',
        loading,
        markup,
        count=1,
    )
    if count != 1:
        raise RuntimeError("Directory panel could not be replaced")

    if "file:///" in markup:
        raise RuntimeError("A local file URL remains in the WordPress template")

    return (
        "<?php\n"
        "/** Generated directory template. Variables are supplied by the shortcode. */\n"
        "defined( 'ABSPATH' ) || exit;\n"
        "?>\n"
        + markup
        + "\n"
    )


def wordpress_javascript(javascript: str) -> str:
    old_data = (
        "  var DATA = JSON.parse(document.getElementById('ottrx-data').textContent);\n"
        "  var FEEDBACK_EMAIL = DATA.meta.email;"
    )
    new_data = (
        "  var DATA_URL = root.getAttribute('data-data-url');\n"
        "\n"
        "  function boot(DATA) {\n"
        "  var FEEDBACK_EMAIL = DATA.meta.email;"
    )
    if old_data not in javascript:
        raise RuntimeError("Expected synchronous JSON initialization was not found")
    javascript = javascript.replace(old_data, new_data, 1)

    javascript = javascript.replace(
        "  var LANG = 'en';",
        "  var LANG = /^fr\\b/i.test(root.getAttribute('lang') || document.documentElement.lang || '') ? 'fr' : 'en';",
        1,
    )
    javascript = javascript.replace(
        "  var LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';\n"
        "  var LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';",
        "  var LEAFLET_CSS = root.getAttribute('data-leaflet-css');\n"
        "  var LEAFLET_JS = root.getAttribute('data-leaflet-js');",
        1,
    )
    javascript = javascript.replace(
        "    var docEl = document.documentElement;\n"
        "    if (docEl) docEl.setAttribute('lang', LANG);\n"
        "    root.setAttribute('lang', LANG);",
        "    root.setAttribute('lang', LANG);",
        1,
    )

    old_end = "  readHash();\n  applyLang();\n  render();\n})();"
    new_end = (
        "  readHash();\n"
        "  applyLang();\n"
        "  render();\n"
        "  root.setAttribute('aria-busy', 'false');\n"
        "  }\n"
        "\n"
        "  function bootError() {\n"
        "    var panel = root.querySelector('[data-panel]');\n"
        "    var fr = /^fr\\b/i.test(root.getAttribute('lang') || '');\n"
        "    if (panel) panel.innerHTML = '<div class=\"ottrx__warn\" role=\"alert\">' +\n"
        "      (fr ? 'Le répertoire ne peut pas être chargé pour le moment. Veuillez réessayer.' :\n"
        "            'The directory could not be loaded. Please try again.') + '</div>';\n"
        "    root.setAttribute('aria-busy', 'false');\n"
        "    root.classList.add('ottrx--load-error');\n"
        "  }\n"
        "\n"
        "  if (!DATA_URL || !window.fetch) { bootError(); return; }\n"
        "  window.fetch(DATA_URL, { credentials: 'same-origin' })\n"
        "    .then(function (response) {\n"
        "      if (!response.ok) throw new Error('Directory data request failed');\n"
        "      return response.json();\n"
        "    })\n"
        "    .then(boot)\n"
        "    .catch(bootError);\n"
        "})();"
    )
    if old_end not in javascript:
        raise RuntimeError("Expected application initialization footer was not found")
    javascript = javascript.replace(old_end, new_end, 1)

    if "cdnjs.cloudflare.com" in javascript:
        raise RuntimeError("Remote Leaflet dependency remains in JavaScript")
    if "document.getElementById('ottrx-data')" in javascript:
        raise RuntimeError("Inline JSON dependency remains in JavaScript")
    return javascript


def wordpress_css(css: str) -> str:
    adapter = r"""

/* ============================================================
   WordPress / Breakdance design-system adapter
   Uses the site's semantic variables and inherited typefaces.
   ============================================================ */
.ottrx.ottrx--wordpress{
  --ott-primary:var(--bde-brand-primary-color,#3988BB);
  --ott-primary-fg:#FFFFFF;
  --ott-secondary:#0E5F6E;
  --ott-accent:#2B668C;
  --ott-accent-fg:#FFFFFF;
  --ott-clinical:#1BBEDC;
  --ott-bg:var(--bde-background-color,#FFFFFF);
  --ott-surface:#F6F6F5;
  --ott-surface-2:#EEF5F7;
  --ott-text:var(--bde-headings-color,#1F2738);
  --ott-muted:#4F4F4F;
  --ott-border:var(--bde-form-input-border-color,#D1D5DB);
  --ott-border-strong:#9CA3AF;
  --ott-radius:var(--bde-button-border-radius,3px);
  --ott-font:"Roboto",sans-serif;
  width:100%;max-width:none;margin:0;padding:0;
  font-family:"Roboto",sans-serif;
}
.ottrx--wordpress .ottrx__title,
.ottrx--wordpress .ottrx__h2,
.ottrx--wordpress .ottrx__h3,
.ottrx--wordpress .ottrx__cardname,
.ottrx--wordpress .ottrx__mapside h4{
  font-family:"Figtree",sans-serif;
  color:var(--bde-headings-color,#1F2738);
}
.ottrx--wordpress .ottrx__title{font-size:clamp(40px,4.4vw,56px);font-weight:800;line-height:1.08}
.ottrx--wordpress .ottrx__head{border-bottom-color:#0E5F6E}
.ottrx--wordpress .ottrx__tab,
.ottrx--wordpress .ottrx__clear,
.ottrx--wordpress .ottrx__langbtn,
.ottrx--wordpress .ottrx__btn,
.ottrx--wordpress .ottrx__more,
.ottrx--wordpress input,
.ottrx--wordpress select{border-radius:var(--bde-button-border-radius,3px)}
.ottrx--wordpress .ottrx__lang{display:none}
.ottrx--wordpress .ottrx__loading{min-height:260px;display:flex;align-items:center;justify-content:center;gap:12px;color:var(--ott-muted)}
.ottrx--wordpress .ottrx__spinner{width:22px;height:22px;border:3px solid var(--ott-border);border-top-color:var(--ott-primary);border-radius:50%;animation:ottrx-spin .8s linear infinite}
@keyframes ottrx-spin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){.ottrx--wordpress .ottrx__spinner{animation:none;border-top-color:var(--ott-border)}}
"""
    return css.rstrip() + adapter + "\n"


def build_manifest(data: dict, source_sha: str) -> dict:
    specialist_rows = [row for group in data["specialists"] for row in group["rows"]]
    unique_specialists = {
        (
            row.get("_cpso", ""),
            row.get("name", "").casefold(),
            row.get("site", "").casefold(),
        )
        for row in specialist_rows
    }
    return {
        "pluginVersion": "1.0.0",
        "builtAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sourceFile": SOURCE.name,
        "sourceSha256": source_sha,
        "dataCompiled": data["meta"].get("compiled"),
        "counts": {
            "specialistGroups": len(data["specialists"]),
            "specialistOccurrences": len(specialist_rows),
            "uniqueSpecialists": len(unique_specialists),
            "services": len(data["svcRows"]),
            "serviceSections": len(data["services"]),
            "faxEntries": len(data["fax"]),
            "routingEntries": len(data["routing"]),
            "resourceSections": len(data["resources"]),
            "formAgencies": len(data["forms"]),
        },
    }


def main() -> None:
    css, markup, javascript, data = extract_source()
    source_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    manifest = build_manifest(data, source_sha)

    write_generated("assets/css/directory.css", wordpress_css(css))
    write_generated("assets/js/directory.js", wordpress_javascript(javascript))
    write_generated(
        "assets/data/directory.json",
        json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n",
    )
    write_generated("templates/directory.php", wordpress_markup(markup))
    write_generated("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")

    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
