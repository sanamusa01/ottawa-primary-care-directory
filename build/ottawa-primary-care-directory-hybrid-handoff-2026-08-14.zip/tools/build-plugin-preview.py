#!/usr/bin/env python3
"""Generate a local, read-only browser preview of the WordPress plugin."""

from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
PLUGIN = ROOT / "ottawa-primary-care-directory"
OUTPUT = ROOT / "build" / "preview.html"


def main() -> None:
    template = (PLUGIN / "templates/directory.php").read_text(encoding="utf-8")
    template = template.split("?>", 1)[1]
    template = template.replace(
        "<?php echo esc_attr( $directory_language ); ?>",
        "en",
    )
    template = template.replace(
        "<?php echo esc_url( $directory_data_url ); ?>",
        "/ottawa-primary-care-directory/assets/data/directory.json",
    )
    template = template.replace(
        "<?php echo esc_url( $leaflet_css_url ); ?>",
        "/ottawa-primary-care-directory/vendor/leaflet/leaflet.css",
    )
    template = template.replace(
        "<?php echo esc_url( $leaflet_js_url ); ?>",
        "/ottawa-primary-care-directory/vendor/leaflet/leaflet.js",
    )

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Ottawa Primary Care Directory — Local Plugin Preview</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Figtree:wght@700;800&display=swap">
  <link rel="stylesheet" href="/ottawa-primary-care-directory/assets/css/directory.css">
  <style>
    :root{{--bde-brand-primary-color:#3988BB;--bde-headings-color:#1F2738;--bde-background-color:#fff;--bde-form-input-border-color:#D1D5DB;--bde-button-border-radius:3px}}
    body{{margin:0;background:#fff;color:#4f4f4f;font:16px/1.4 Roboto,sans-serif}}
    .preview-shell{{max-width:1240px;margin:0 auto;padding:80px 20px}}
  </style>
</head>
<body>
  <div class="preview-shell">{template}</div>
  <script defer src="/ottawa-primary-care-directory/assets/js/directory.js"></script>
</body>
</html>
"""
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(html, encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
