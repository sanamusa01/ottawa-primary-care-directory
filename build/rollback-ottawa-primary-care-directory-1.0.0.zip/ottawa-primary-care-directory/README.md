# Ottawa Primary Care Directory (Legacy Rollback Only)

> **Deprecated:** The active integration now uses the public Business Directory Plugin from WordPress.org. This bespoke Leaflet plugin is retained only for temporary rollback and historical review. Do not activate or deploy it as the production solution without a new security and maintenance decision.

WordPress integration for the authoritative Monica directory source.

## Shortcode

`[ottawa_primary_care_directory]`

## Data updates

The public dataset is stored in `assets/data/directory.json`. Rebuild from the
authoritative HTML with:

```bash
python3 tools/build-wordpress-plugin.py
python3 tools/validate-wordpress-plugin.py
```

The build manifest records the source SHA-256 and expected record counts.

## WordPress requirements

- WordPress 6.3 or newer
- PHP 7.4 or newer
- A page containing the shortcode exactly once

The plugin does not modify the database on activation and does not create or
delete pages. Leaflet is bundled locally; OpenStreetMap map tiles load only
when a visitor opens the Map tab.
