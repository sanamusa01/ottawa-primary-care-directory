# Changelog

## 1.0.0 — 2026-08-13

- Initial WordPress integration generated from the latest Monica HTML source.
- Separated the large JSON dataset from WordPress page content.
- Added a shortcode-based integration for the existing Breakdance page.
- Mapped directory styling to the Ottawa OHT-ÉSO Breakdance design system.
- Integrated language selection with the WordPress/TranslatePress locale.
- Removed hard-coded local file links.
- Bundled Leaflet locally and retained OpenStreetMap attribution and fallback.

